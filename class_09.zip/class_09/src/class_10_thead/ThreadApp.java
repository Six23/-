package class_10_thead;

import java.awt.Color;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class ThreadApp {
	public static void main(String[] args) {
		Frame f = new Frame();
		f.setSize(500, 500);
		f.setVisible(true);
		Graphics g = f.getGraphics();
		f.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
		MyThread mt = new MyThread(g);
		Thread t = new Thread(mt);
		t.start();
	}
}

class MyThread implements Runnable {
	private Graphics g;
	int width = 400;
	int height = 400;
	boolean direct = true;

	public MyThread(Graphics g) {
		this.g = g;
	}

	public void run() {
		while(true){
			try {
				Thread.sleep(50);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			g.setColor(Color.white);
			g.fillRect(0,0,500,500);

			g.setColor(Color.black);
			g.drawOval(50, 50, width, height);
			if(direct){
				width--;
				height--;
				if(width == 0){
					direct = false;
				}
			}else{
				width++;
				height++;
				if(width == 400){
					direct = true;
				}
			}
		}
	}
}
