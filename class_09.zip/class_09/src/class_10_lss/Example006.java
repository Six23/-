package class_10_lss;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class Example006 {
	public static void main(String[] args) {
		Frame f = new Frame();
		f.setSize(500, 500);
		f.setVisible(true);
		MyPanl mp = new MyPanl();
		f.add(mp);

		f.addWindowFocusListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e){
				System.exit(0);
			}
		});
	}
}


class MyPanl extends Panel {
	public void paint(Graphics g) {
		int width = 400;
		int height = 400;
		boolean direct = true;
		while (true) {
			try {
				Thread.sleep(50);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			g.setColor(Color.white);
			g.fillRect(0, 0, 500, 500);
			g.setColor(Color.black);
			g.drawRect(0, 0, width, height);
			if (direct) {
				width --;
				height --;
				if(width==0){
					direct=false;
				}
			} else {
				width++;
				height++;
				if(width==400){
					direct=true;
				}
			}
		}
	}

}
