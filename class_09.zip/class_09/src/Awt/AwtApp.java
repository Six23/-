package Awt;

import java.awt.*;
import java.awt.event.*;

public class AwtApp {
	public static void main(String[] args) {
		MainFrame f = new MainFrame();
		MyFrame mf = new MyFrame(f);
	}
}
