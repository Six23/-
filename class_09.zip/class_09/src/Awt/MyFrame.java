package Awt;

import java.awt.*;
import java.awt.event.*;

public class MyFrame extends Frame {
	public MyFrame(final MainFrame f) {
		setLayout(null);
		setSize(400, 500);
		setVisible(true);
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
		final TextField t = new TextField();
		t.setBounds(40, 60, 100, 30);
		t.setText("0");
		add(t);
		Button btn = new Button("��¼");
		btn.setBounds(40, 90, 100, 30);
		btn.addMouseListener(new MouseAdapter() {

			@Override // �����ť����¼�
			// public void mouseClicked(MouseEvent arg0) {
			// int value = Integer.parseInt(t.getText());
			// value++;
			// t.setText(String.valueOf(value));
			// if(value==10){
			// f.setText(String.valueOf(value));
			// f.setVisible(true);//��������������
			// setVisible(false);
			//
			// }
			public void mouseClicked(MouseEvent arg0) {
				String name = t.getText();
				f.setText(name);
				f.setVisible(true);// ��������������
				setVisible(false);

			}
		});
		add(btn);
	}
}
