package Awt;

import java.awt.*;
import java.awt.event.*;

public class MainFrame extends Frame {
	Label l = new Label("��ӭ��¼��");

	public MainFrame() {
		setLayout(null);
		setSize(400, 200);

		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});

		l.setBounds(40, 40, 200, 30);
		add(l);
	}

	public void setText(String text) {
		l.setText(text+"��ӭ��¼��");
	}
}
