package class_08_aic_ex;

import java.util.*;

public class AIC_EXApp {
    public static void main(String[] args) {
        IRW rw = ConsoleRW.getInstance();
        Receiver receiver = new Receiver(rw, getStudents());
        rw.writeln("��ӭ����ѧ������ϵͳ��");
        
        int operation = receiver.getOperation();
        while (operation != 0) {
            receiver.run(operation);
            operation = receiver.getOperation();
        }
        rw.writeln("-------------------�˳�ϵͳ-------------------");
    }

    private static List<Student> getStudents() {
		List<Student> students = new ArrayList<Student>();
		students.add(new Student("21800504", "wyx"));
		students.add(new Student("21800505", "sx"));
		students.add(new Student("21800509", "zl"));
		return students;
	}
}