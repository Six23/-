package class_08_aic_ex;

public interface IRW {
    int readInt();
    void writeln(String mes);
    void write(String s);
}
