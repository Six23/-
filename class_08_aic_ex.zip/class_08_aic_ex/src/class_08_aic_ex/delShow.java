package class_08_aic_ex;
import java.util.List;

public class delShow extends Command {
	public static final int num = 2;
    private static Command instance;

    private delShow() {
        super(num, "ɾ������");
    }
    public static Command getInstance() {
        if (instance == null) {
            instance = new delShow();
        }
        return instance;
    }
    public String run(List<Student> students) {
        StringBuffer res = new StringBuffer();
        res.append("���\t����\tѧ��" + "\r\n");
        for (int i = 0; i < students.size(); i++) {
            res.append(i + 1 + "\t" + students.get(i).toString() + "\r\n");
        }
        return res.toString();
    }
}
