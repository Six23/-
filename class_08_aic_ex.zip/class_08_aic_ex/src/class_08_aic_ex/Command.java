package class_08_aic_ex;

import java.util.List;

public class Command {
    private int num,num2;
    private String mes,mes2;
    public Command(int num, String mes) {
        this.num = num;
        this.mes = mes;
    }
    public String run(List<Student> students) {
        return null;
    }
    public String toString() {
        return num + ":" + mes;
    }
}
